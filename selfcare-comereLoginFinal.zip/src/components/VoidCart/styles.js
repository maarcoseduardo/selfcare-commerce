import styled from "styled-components";
import { Link } from "react-router-dom";

export const Container = styled.div`
`;
export const Content = styled.div`
`;

export const H1 = styled.h1`
`;

export const Paragraph = styled.p`
`;

export const Anchor = styled(Link)`
`;